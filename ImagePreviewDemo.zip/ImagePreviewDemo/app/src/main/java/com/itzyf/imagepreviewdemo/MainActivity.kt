package com.itzyf.imagepreviewdemo

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    val images = listOf(
        "http://pic1.win4000.com/wallpaper/2018-10-10/5bbd63758d1ea.jpg",
        "http://pic1.win4000.com/wallpaper/2018-10-10/5bbd637697588.jpg",
        "http://pic1.win4000.com/wallpaper/2018-10-10/5bbd6374c4233.jpg",
        "http://pic1.win4000.com/wallpaper/2018-10-10/5bbd6377a63ee.jpg",
        "http://pic1.win4000.com/wallpaper/2018-10-10/5bbd6378a1fdc.jpg",
        "http://pic1.win4000.com/wallpaper/2018-10-10/5bbd6379b2b20.jpg"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val fragment = PreviewItemFragment.newInstance(images[0])

        supportFragmentManager.beginTransaction().replace(R.id.content, fragment).commit()
    }
}
