package com.itzyf.imagepreviewdemo

import android.net.Uri
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import it.sephiroth.android.library.imagezoom.ImageViewTouch
import it.sephiroth.android.library.imagezoom.ImageViewTouchBase

class PreviewItemFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_preview_image, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val image = view!!.findViewById<ImageViewTouch>(R.id.image_view)
        image.displayType = ImageViewTouchBase.DisplayType.FIT_TO_SCREEN
        val item = arguments!!.get(ARGS_ITEM)
        if (item is Uri || item is String) {
            Glide.with(activity!!).load(item).into(image)
        }
    }

    fun resetView() {
        (view as ImageViewTouch).resetMatrix()
    }

    companion object {

        private const val ARGS_ITEM = "args_item"

        fun newInstance(item: Any): PreviewItemFragment {
            val fragment = PreviewItemFragment()
            val bundle = Bundle()
            if (item is String)
                bundle.putString(ARGS_ITEM, item)
            else if (item is Uri)
                bundle.putParcelable(ARGS_ITEM, item)
            fragment.arguments = bundle
            return fragment
        }
    }
}